document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    if (name && email) {
        document.getElementById('message').textContent = Thank you for registering, ${name}!;
        document.getElementById('message').style.color = 'green';
    } else {
        document.getElementById('message').textContent = 'Please fill in all fields.';
        document.getElementById('message').style.color = 'red';
    }
});